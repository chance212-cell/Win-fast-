const express=require('express');
const path=require('path');
const Database=require('better-sqlite3');
const bcrypt=require('bcryptjs');
const jwt=require('jsonwebtoken');
const app=express();
const db=new Database(path.join(__dirname,'winfast.db'));
const SECRET=process.env.WINFAST_SECRET||'change-this-demo-secret';
app.use(express.json());
app.use(express.static(__dirname));
db.exec(`CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY AUTOINCREMENT,email TEXT UNIQUE NOT NULL,password TEXT NOT NULL,balance REAL DEFAULT 0,created_at TEXT DEFAULT CURRENT_TIMESTAMP); CREATE TABLE IF NOT EXISTS selections(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER,event TEXT,market TEXT,odd REAL,created_at TEXT DEFAULT CURRENT_TIMESTAMP);`);
function auth(req,res,next){try{const h=req.headers.authorization||''; const t=h.startsWith('Bearer ')?h.slice(7):''; req.user=jwt.verify(t,SECRET); next()}catch(e){res.status(401).json({error:'Authentication required'})}}
app.post('/api/register',(req,res)=>{const {email,password}=req.body||{}; if(!email||!password||password.length<6)return res.status(400).json({error:'Email and password (6+ characters) are required'}); try{const hash=bcrypt.hashSync(password,10); const r=db.prepare('INSERT INTO users(email,password) VALUES(?,?)').run(email.toLowerCase(),hash); const token=jwt.sign({id:r.lastInsertRowid,email:email.toLowerCase()},SECRET,{expiresIn:'7d'}); res.json({token,user:{email:email.toLowerCase(),balance:0}})}catch(e){res.status(409).json({error:'Email already registered'})}});
app.post('/api/login',(req,res)=>{const {email,password}=req.body||{}; const u=db.prepare('SELECT * FROM users WHERE email=?').get((email||'').toLowerCase()); if(!u||!bcrypt.compareSync(password||'',u.password))return res.status(401).json({error:'Invalid credentials'}); const token=jwt.sign({id:u.id,email:u.email},SECRET,{expiresIn:'7d'}); res.json({token,user:{email:u.email,balance:u.balance}})});
app.get('/api/me',auth,(req,res)=>{const u=db.prepare('SELECT id,email,balance,created_at FROM users WHERE id=?').get(req.user.id); res.json(u)});
app.get('/api/selections',auth,(req,res)=>res.json(db.prepare('SELECT event,market,odd,created_at FROM selections WHERE user_id=? ORDER BY id DESC').all(req.user.id)));
app.post('/api/selections',auth,(req,res)=>{const {event,market,odd}=req.body||{}; if(!event||!market||typeof odd!=='number')return res.status(400).json({error:'Invalid selection'}); db.prepare('INSERT INTO selections(user_id,event,market,odd) VALUES(?,?,?,?)').run(req.user.id,event,market,odd); res.json({ok:true})});
app.get('*',(req,res)=>res.sendFile(path.join(__dirname,'index.html')));
app.listen(process.env.PORT||3000,()=>console.log('Win Fast demo running on http://localhost:'+(process.env.PORT||3000)));
